package pl.lodz.p.sise;

public enum Ruch {
	L, P, G, D 
}
