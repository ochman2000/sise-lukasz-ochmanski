package pl.lodz.p.sise;

public enum Ruch {
	L, P, G, D
//	D, G, P, L
//	G, D, L, P
//	P, L, D, G
}
