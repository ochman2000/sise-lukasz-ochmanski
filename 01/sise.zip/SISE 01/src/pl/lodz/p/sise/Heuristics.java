package pl.lodz.p.sise;

public enum Heuristics {
	None, ManhattanDistance, HammingDistance, SumOfManhattanDistances
}
